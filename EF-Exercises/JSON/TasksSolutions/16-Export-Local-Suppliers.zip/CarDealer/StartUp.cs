﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using CarDealer.Data;
using CarDealer.DTOs.Export;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using Castle.Core.Resource;
using Newtonsoft.Json;
using System.IO;

namespace CarDealer
{
	public class StartUp
	{
		private const string _DataPath = "../../../Datasets/";
		public static void Main()
		{
			var context = new CarDealerContext();

			// 09. Import Suppliers
			// string suppliersJson = File.ReadAllText(_DataPath + "suppliers.json");
			// Console.WriteLine(ImportSuppliers(context, suppliersJson));

			// 10. Import Parts
			// string partsJson = File.ReadAllText(_DataPath + "parts.json");
			// Console.WriteLine(ImportParts(context, partsJson));

			// 11.Import Cars
			// string carsJson = File.ReadAllText(_DataPath + "cars.json");
			// Console.WriteLine(ImportCars(context, carsJson));

			// 12. Import Customers
			// string customersJson = File.ReadAllText(_DataPath + "customers.json");
			// Console.WriteLine(ImportCustomers(context, customersJson));

			// 13. Import Sales
			// string salesJson = File.ReadAllText(_DataPath + "sales.json");
			// Console.WriteLine(ImportSales(context, salesJson));

			// 14. Export Ordered Customers
			// Console.WriteLine(GetOrderedCustomers(context));

			// 15. Export Cars From Make Toyota
			// Console.WriteLine(GetCarsFromMakeToyota(context));

			// 16. Export Local Suppliers
			Console.WriteLine(GetLocalSuppliers(context));


		}
		private static Mapper GetMapper()
		{
			var config = new MapperConfiguration(c => c.AddProfile<CarDealerProfile>());
			return new Mapper(config);
		}

		// 09. Import Suppliers
		public static string ImportSuppliers(CarDealerContext context, string inputJson)
		{
			var suppliers = JsonConvert.DeserializeObject<List<Supplier>>(inputJson);

			context.Suppliers.AddRange(suppliers);
			context.SaveChanges();

			return $"Successfully imported {suppliers.Count}.";
		}

		// 10. Import Parts
		public static string ImportParts(CarDealerContext context, string inputJson)
		{
			var validSuppliersIds = context.Suppliers
				.Select(x => x.Id)
				.ToList();

			var parts = JsonConvert.DeserializeObject<List<Part>>(inputJson)
				.Where(p => validSuppliersIds.Contains(p.SupplierId))
				.ToList();

			context.Parts.AddRange(parts);
			context.SaveChanges();

			return $"Successfully imported {parts.Count}.";
		}

		// 11.Import Cars
		public static string ImportCars(CarDealerContext context, string inputJson)
		{
			var cars = new List<Car>();
			var partsCars = new List<PartCar>();

			var importedCarsData = JsonConvert.DeserializeObject<List<CarImportDTO>>(inputJson);

			foreach (var data in importedCarsData)
			{
				var car = new Car
				{
					Make = data.Make,
					Model = data.Model,
					TraveledDistance = data.TraveledDistance
				};
				cars.Add(car);

				foreach (var partId in data.PartsId)
				{
					partsCars.Add(new PartCar
					{
						Car = car,
						PartId = partId,
					});
				}
			}

			context.Cars.AddRange(cars);
			context.PartsCars.AddRange(partsCars);
			context.SaveChanges();

			return $"Successfully imported {importedCarsData.Count}.";
		}

		// 12. Import Customers
		public static string ImportCustomers(CarDealerContext context, string inputJson)
		{
			var customers = JsonConvert.DeserializeObject<List<Customer>>(inputJson);

			context.Customers.AddRange(customers);
			context.SaveChanges();

			return $"Successfully imported {customers.Count}.";
		}

		// 13. Import Sales
		public static string ImportSales(CarDealerContext context, string inputJson)
		{
			var sales = JsonConvert.DeserializeObject<List<Sale>>(inputJson);

			context.Sales.AddRange(sales);
			context.SaveChanges();

			return $"Successfully imported {sales.Count}.";
		}

		// 14. Export Ordered Customers
		public static string GetOrderedCustomers(CarDealerContext context)
		{
			var mapper = GetMapper();

			var customers = context.Customers
				.OrderBy(c => c.BirthDate)
				.ThenBy(c => c.IsYoungDriver)
				.ProjectTo<CustomerExportDTO>(mapper.ConfigurationProvider)
				.ToList();

			return JsonConvert.SerializeObject(customers, Formatting.Indented);
		}

		// 15. Export Cars From Make Toyota
		public static string GetCarsFromMakeToyota(CarDealerContext context)
		{
			var mapper = GetMapper();

			var toyotaCars = context.Cars
				.Where(c => c.Make == "Toyota")
				.OrderBy(c => c.Model)
				.ThenByDescending(c => c.TraveledDistance)
				.ProjectTo<CarExportDTO>(mapper.ConfigurationProvider)
				.ToList();

			return JsonConvert.SerializeObject(toyotaCars, Formatting.Indented);
		}

		// 16. Export Local Suppliers
		public static string GetLocalSuppliers(CarDealerContext context)
		{
			var mapper = GetMapper();

			var localSuppliers = context.Suppliers
				.Where(s => !s.IsImporter)
				.ProjectTo<SupplierExportDTO>(mapper.ConfigurationProvider)
				.ToList();

			return JsonConvert.SerializeObject(localSuppliers, Formatting.Indented);
		}
	}
}