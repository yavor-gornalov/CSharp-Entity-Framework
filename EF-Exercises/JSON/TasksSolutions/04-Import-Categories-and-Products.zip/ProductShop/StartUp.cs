﻿using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;

namespace ProductShop;

public class StartUp
{
	private const string _DatasetsPath = "../../../Datasets/";
	public static void Main()
	{
		ProductShopContext context = new();

		// 01. Import Users
		// var usersJson = File.ReadAllText(_DatasetsPath + "users.json");
		// Console.WriteLine(ImportUsers(context, usersJson));

		// 02.Import Products
		// var productsJson = File.ReadAllText(_DatasetsPath + "products.json");
		// Console.WriteLine(ImportProducts(context, productsJson));

		// 03. Import Categories
		// var categoriesJson = File.ReadAllText(_DatasetsPath + "categories.json");
		// Console.WriteLine(ImportCategories(context, categoriesJson));

		// 04. Import Categories and Products
		var categoriesProductsJson = File.ReadAllText(_DatasetsPath + "categories-products.json");
		Console.WriteLine(ImportCategoryProducts(context, categoriesProductsJson));
	}



	// 01. Import Users
	public static string ImportUsers(ProductShopContext context, string inputJson)
	{
		var users = JsonConvert.DeserializeObject<List<User>>(inputJson);

		context.Users.AddRange(users);
		context.SaveChanges();

		return $"Successfully imported {users.Count}";
	}

	// 02. Import Products
	public static string ImportProducts(ProductShopContext context, string inputJson)
	{
		var products = JsonConvert.DeserializeObject<List<Product>>(inputJson);

		context.Products.AddRange(products);
		context.SaveChanges();

		return $"Successfully imported {products.Count}";
	}

	// 03. Import Categories
	public static string ImportCategories(ProductShopContext context, string inputJson)
	{
		var categories = JsonConvert.DeserializeObject<List<Category>>(inputJson)
			.Where(c => c.Name is not null)
			.ToList();

		context.Categories.AddRange(categories);
		context.SaveChanges();

		return $"Successfully imported {categories.Count}";
	}

	// 04. Import Categories and Products
	public static string ImportCategoryProducts(ProductShopContext context, string inputJson)
	{
		var categoryProducts = JsonConvert.DeserializeObject<List<CategoryProduct>>(inputJson);

		context.CategoriesProducts.AddRange(categoryProducts);
		context.SaveChanges();

		return $"Successfully imported {categoryProducts.Count}";
	}
}