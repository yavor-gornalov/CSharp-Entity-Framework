﻿using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;

namespace ProductShop;

public class StartUp
{
	private const string _DatasetsPath = "../../../Datasets/";
	public static void Main()
	{
		ProductShopContext context = new();

		// 01. Import Users
		//var usersJson = File.ReadAllText(_DatasetsPath + "users.json");
		//Console.WriteLine(ImportUsers(context, usersJson));

		//02.Import Products
		var productsJson = File.ReadAllText(_DatasetsPath + "products.json");
		Console.WriteLine(ImportProducts(context, productsJson));
	}

	//01. Import Users
	public static string ImportUsers(ProductShopContext context, string inputJson)
	{
		var users = JsonConvert.DeserializeObject<List<User>>(inputJson);

		context.AddRange(users);
		context.SaveChanges();

		return $"Successfully imported {users.Count}";
	}

	//02. Import Products
	public static string ImportProducts(ProductShopContext context, string inputJson)
	{
		var products = JsonConvert.DeserializeObject<List<Product>>(inputJson);

		context.AddRange(products);
		context.SaveChanges();

		return $"Successfully imported {products.Count}";
	}
}