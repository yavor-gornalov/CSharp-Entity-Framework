﻿using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.Models;

namespace ProductShop;

public class StartUp
{
	private const string _DatasetsPath = "../../../Datasets/";
	public static void Main()
	{
		ProductShopContext context = new();

		// 01. Import Users
		var usersJson = File.ReadAllText(_DatasetsPath + "users.json");
        Console.WriteLine(ImportUsers(context, usersJson));
    }

	//01. Import Users
	public static string ImportUsers(ProductShopContext context, string inputJson)
	{
		var users = JsonConvert.DeserializeObject<List<User>>(inputJson);

		context.AddRange(users);
		context.SaveChanges();

		return $"Successfully imported {users.Count}";
	}
}