﻿using CarDealer.Data;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        private const string _DataPath = "../../../Datasets/";
        public static void Main()
        {
            var context = new CarDealerContext ();

			// 09. Import Suppliers
			string suppliersJson = File.ReadAllText (_DataPath + "suppliers.json");
            Console.WriteLine(ImportSuppliers(context, suppliersJson));

        }
		
        // 09. Import Suppliers
        public static string ImportSuppliers(CarDealerContext context, string inputJson) {
            var suppliers = JsonConvert.DeserializeObject<List<Supplier>>(inputJson);

            context.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count}.";
        }
    }
}