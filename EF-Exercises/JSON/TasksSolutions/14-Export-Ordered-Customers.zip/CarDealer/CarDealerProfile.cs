﻿using AutoMapper;
using CarDealer.DTOs.Export;
using CarDealer.Models;
using System.Globalization;

namespace CarDealer
{
	public class CarDealerProfile : Profile
	{
		public CarDealerProfile()
		{
			CreateMap<Customer, CustomerExportDTO>()
				.ForMember(x => x.BirthDate, y => y.MapFrom(s => s.BirthDate.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture)));
		}
	}
}
