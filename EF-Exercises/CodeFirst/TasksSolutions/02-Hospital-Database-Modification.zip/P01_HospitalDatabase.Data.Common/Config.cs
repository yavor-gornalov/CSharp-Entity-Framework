﻿namespace P01_HospitalDatabase.Data.Common;

public static class Config
{
    public const string ConnectionString =
        @"Server=.\SQLEXPRESS;Database=HospitalDatabase;Integrated Security=True;";
}
