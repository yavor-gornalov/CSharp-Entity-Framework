﻿namespace P03_SalesDatabase;

internal class StartUp
{
    static void Main()
    {
    }
}
