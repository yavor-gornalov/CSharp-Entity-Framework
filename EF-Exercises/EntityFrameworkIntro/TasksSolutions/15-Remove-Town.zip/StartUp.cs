﻿using Microsoft.VisualBasic;
using SoftUni.Data;
using System.Globalization;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            SoftUniContext context = new();
            Console.WriteLine(RemoveTown(context));
        }

        public static string RemoveTown(SoftUniContext context)
        {
            var townToRemove = context.Towns.FirstOrDefault(t => t.Name == "Seattle");

            var addressesToRemove = context.Addresses
                .Where(a => a.Town!.Name == townToRemove!.Name)
                .ToList();

            var employeesWithAddressesToRemove = context.Employees
                .Where(e => e.Address!.Town!.Name == townToRemove!.Name)
                .ToList();

            foreach (var e in employeesWithAddressesToRemove)
                e.AddressId = null;

            foreach (var a in addressesToRemove)
                context.Addresses.Remove(a);

            context.Towns.Remove(townToRemove);

            context.SaveChanges();

            return $"{addressesToRemove.Count} addresses in Seattle were deleted";
        }
    }
}
