﻿using Microsoft.VisualBasic;
using SoftUni.Data;
using System.Globalization;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            SoftUniContext context = new();
            Console.WriteLine(IncreaseSalaries(context));
        }

        public static string IncreaseSalaries(SoftUniContext context)
        {
            var departmentsForPromotion = new List<string>()
            {
                "Engineering",
                "Tool Design",
                "Marketing",
                "Information Services"
            };
            var employees = context.Employees
                .Where(e => departmentsForPromotion.Contains(e.Department.Name))
                .OrderBy(e => e.FirstName)
                .ThenBy(e => e.LastName)
                .ToList();

            foreach (var e in employees)
                e.Salary *= 1.12m;

            context.SaveChanges();

            var sb = new StringBuilder();
            foreach (var e in employees)
                sb.AppendLine($"{e.FirstName} {e.LastName} (${e.Salary:f2})");
        
            return sb.ToString().Trim();
        }
    }
}
