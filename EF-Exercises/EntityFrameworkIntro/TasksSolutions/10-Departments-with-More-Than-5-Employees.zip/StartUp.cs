﻿using SoftUni.Data;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            SoftUniContext context = new();
            Console.WriteLine(GetDepartmentsWithMoreThan5Employees(context));
        }

        public static string GetDepartmentsWithMoreThan5Employees(SoftUniContext context)
        {
            var departments = context.Departments
                .Where(d => d.Employees.Count() > 5)
                .OrderBy(d => d.Employees.Count())
                .ThenBy(d => d.Name)
                .Select(d => new { 
                    DepartmentName = d.Name,
                    ManagerFirstName = d.Manager.FirstName, 
                    ManagerLastName = d.Manager.LastName,
                    DepartmentEmployees = d.Employees
                        .Where(e => e.EmployeeId != d.ManagerId)
                        .OrderBy(e => e.FirstName)
                        .OrderBy (e => e.LastName)
                        .Select(e => new { 
                            EmployeeFirstName = e.FirstName,
                            EmployeeLastName = e.LastName,
                            EmployeeJobTitle = e.JobTitle,
                        })
                        .ToList()
                })
                .ToList();

            var sb = new StringBuilder();

            foreach(var d in departments)
            {
                sb.AppendLine($"{d.DepartmentName} – {d.ManagerFirstName} {d.ManagerLastName}");
                foreach(var e in d.DepartmentEmployees)
                    sb.AppendLine($"{e.EmployeeFirstName} {e.EmployeeLastName} - {e.EmployeeJobTitle}");
            }

            return sb.ToString().Trim();
        }
    }
}
