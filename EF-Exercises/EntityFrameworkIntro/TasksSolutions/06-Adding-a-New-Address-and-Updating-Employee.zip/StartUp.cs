﻿using SoftUni.Data;
using SoftUni.Models;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            SoftUniContext context = new SoftUniContext();
            var firstEmpolyee = context.Employees.Find(1);
            Console.WriteLine(AddNewAddressToEmployee(context));
        }

        public static string AddNewAddressToEmployee(SoftUniContext context) {
            var address = new Address();
            address.AddressText = "Vitoshka 15";
            address.TownId = 4;

            var employee = context.Employees
                .FirstOrDefault(e => e.LastName == "Nakov");

            employee.Address = address;

            context.SaveChanges();

            return string.Join(
                Environment.NewLine, 
                context.Employees
                       .OrderByDescending(e => e.AddressId)
                       .Take(10)
                       .Select(e => e.Address.AddressText)
                       .ToList());
        }
    }
}
