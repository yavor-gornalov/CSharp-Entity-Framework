﻿using Microsoft.VisualBasic;
using SoftUni.Data;
using System.Globalization;
using System.Text;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            SoftUniContext context = new();
            Console.WriteLine(DeleteProjectById(context));
        }

        public static string DeleteProjectById(SoftUniContext context)
        {
            var projectToRemove = context.Projects.Find(2);

            var employeesProjects = context.EmployeesProjects
                .Where(ep => ep.ProjectId == projectToRemove!.ProjectId)
                .ToList();

            foreach (var ep in employeesProjects)
                context.EmployeesProjects.Remove(ep);

            context.Projects.Remove(projectToRemove!);

            context.SaveChanges();

            var sb = new StringBuilder();
            context.Projects
                .Take(10)
                .ToList()
                .ForEach(p => sb.AppendLine(p.Name));

            return sb.ToString().Trim();
        }
    }
}
