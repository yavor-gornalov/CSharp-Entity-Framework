﻿using SoftUni.Data;

namespace SoftUni
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            SoftUniContext context = new SoftUniContext();
            var firstEmpolyee = context.Employees.Find(1);
            Console.WriteLine(GetEmployeesFullInformation(context));
        }

        public static string GetEmployeesFullInformation(SoftUniContext context) {
            var emplyeesData = context.Employees
                .Select(
                    e => $"{e.FirstName} {e.LastName} {e.MiddleName} {e.JobTitle} {e.Salary:f2}"
                ).ToList();
            return string.Join(Environment.NewLine, emplyeesData);
        }
    }
}
