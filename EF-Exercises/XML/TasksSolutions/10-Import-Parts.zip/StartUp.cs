﻿using AutoMapper;
using CarDealer.Data;
using CarDealer.DTOs.Import;
using CarDealer.Models;
using Microsoft.EntityFrameworkCore;
using System.Globalization;
using System.IO;
using System.Text;
using System.Xml.Serialization;

namespace CarDealer;

public class StartUp
{
	private const string _DatasetsPath = "../../../Datasets/";

	public static void Main()
	{
		CarDealerContext context = new CarDealerContext();

		// 09.Import Suppliers
		// string inputSuppliersXml = File.ReadAllText(_DatasetsPath + "suppliers.xml");
		// Console.WriteLine(ImportSuppliers(context, inputSuppliersXml));

		// 10.Import Parts
		string inputPartsXml = File.ReadAllText(_DatasetsPath + "parts.xml");
		Console.WriteLine(ImportParts(context, inputPartsXml));
	}

	// 09.Import Suppliers
	public static string ImportSuppliers(CarDealerContext context, string inputXml)
	{
		var suppliers = DeserializeXml<ImportSupplierDTO>(inputXml, "Suppliers")
			.Select(s => new Supplier
			{
				Name = s.Name,
				IsImporter = s.IsImporter,
			})
			.ToList();

		context.Suppliers.AddRange(suppliers);
		context.SaveChanges();

		return $"Successfully imported {suppliers.Count}";
	}

	// 10.Import Parts
	public static string ImportParts(CarDealerContext context, string inputXml)
	{
		var validSupplierIds = context.Suppliers
			.AsNoTracking()
			.Select(s => s.Id)
			.ToList();

		var parts = DeserializeXml<ImportPartDTO>(inputXml, "Parts")
			.Where(p => validSupplierIds.Contains(p.SupplierId))
			.Select(p => new Part { 
				Name = p.Name,
				Price = p.Price,
				Quantity = p.Quantity,
				SupplierId = p.SupplierId,
			})
			.ToList();

		context.Parts.AddRange(parts);
		context.SaveChanges();

		return $"Successfully imported {parts.Count}";
	}

	// Helpers
	private static Mapper GetMapper()
		=> new(new MapperConfiguration(c => c.AddProfile<CarDealerProfile>()));

	private static T[] DeserializeXml<T>(string inputXml, string rootElement)
	{
		// Create root element
		XmlRootAttribute xmlRootAttribute = new(rootElement);

		// Create xml serializer with type of dto and root element
		XmlSerializer xmlSerializer = new(typeof(T[]), xmlRootAttribute);

		// Create string reader
		using var xmlReader = new StringReader(inputXml);

		// Deserialize inputXml and cast it to dto type
		return (T[])xmlSerializer.Deserialize(xmlReader);
	}

	private static string SerializeToXml<T>(T obj, string xmlRootAttribute, string prefix = "", string ns = "")
	{
		XmlRootAttribute rootAttribute = new(xmlRootAttribute);

		XmlSerializer xmlSerializer = new(typeof(T), rootAttribute);

		StringBuilder stringBuilder = new StringBuilder();

		StringWriter stringWriter = new(stringBuilder, CultureInfo.InvariantCulture);

		using (stringWriter)
		{
			XmlSerializerNamespaces xmlSerializerNamespaces = new();
			xmlSerializerNamespaces.Add(prefix, ns);

			try
			{
				xmlSerializer.Serialize(stringWriter, obj, xmlSerializerNamespaces);
			}
			catch (Exception)
			{
				throw;
			}
		}

		return stringBuilder.ToString();
	}
}