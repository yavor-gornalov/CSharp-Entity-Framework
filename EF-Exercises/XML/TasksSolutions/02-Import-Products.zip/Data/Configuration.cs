﻿namespace ProductShop.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=.\SQLEXPRESS;Database=ProductShopXML;Integrated Security=True;Encrypt=False";
    }
}
