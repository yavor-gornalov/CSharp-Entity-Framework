﻿namespace BookShop
{
    using BookShop.Models.Enums;
    using Data;
    using Initializer;
    using Microsoft.EntityFrameworkCore;
    using System.Collections.Immutable;
    using System.Globalization;
    using System.Text;
    using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();

            //NOTE: Uncomment this line to create/recreate DB locally
            DbInitializer.ResetDatabase(db);

            Console.WriteLine(RemoveBooks(db));
        }
        public static int RemoveBooks(BookShopContext context)
        {
            var booksToRemove = context.Books
                .Where(b => b.Copies < 4200);

            int booksCount = booksToRemove.Count();

            context.RemoveRange(booksToRemove);
            context.SaveChanges();

            return booksCount;
        }
    }
}


