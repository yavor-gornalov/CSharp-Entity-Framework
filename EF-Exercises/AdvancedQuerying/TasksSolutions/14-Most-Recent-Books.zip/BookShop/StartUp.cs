﻿namespace BookShop
{
    using BookShop.Models.Enums;
    using Data;
    using Initializer;
    using Microsoft.EntityFrameworkCore;
    using System.Collections.Immutable;
    using System.Globalization;
    using System.Text;
    using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();

            //NOTE: Uncomment this line to create/recreate DB locally
            //DbInitializer.ResetDatabase(db);

            Console.WriteLine(GetMostRecentBooks(db));
        }
        public static string GetMostRecentBooks(BookShopContext context)
        {
            var categories = context.Categories
                .Select(c => new
                {
                    c.Name,
                    RecentBooks = c.CategoryBooks
                        .OrderByDescending(cb => cb.Book.ReleaseDate)
                        .Select(cb => new
                        {
                            BookTitle = cb.Book.Title,
                            ReleaseYear = cb.Book.ReleaseDate.Value.Year
                        })
                        .Take(3)
                        .ToList()
                })
                .ToList()
                .OrderBy(c => c.Name);

            StringBuilder result = new();

            foreach (var c in categories)
            {
                result.AppendLine($"--{c.Name}");
                foreach (var b in c.RecentBooks)
                {
                    result.AppendLine($"{b.BookTitle} ({b.ReleaseYear})");
                }
            }

            return result.ToString().Trim();
        }
    }
}


