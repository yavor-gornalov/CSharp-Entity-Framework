﻿namespace BookShop
{
    using BookShop.Models.Enums;
    using Data;
    using Initializer;
    using Microsoft.EntityFrameworkCore;
    using System.Collections.Immutable;
    using System.Globalization;
    using System.Text;
    using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();

            //NOTE: Uncomment this line to create/recreate DB locally
            //DbInitializer.ResetDatabase(db);

            Console.WriteLine(CountBooks(db, int.Parse(Console.ReadLine())));
        }
        public static int CountBooks(BookShopContext context, int lengthCheck)
        {
            int result = context.Books
                .Where(b => b.Title.Length > lengthCheck)
                .Count();

            return result;
        }
    }
}


