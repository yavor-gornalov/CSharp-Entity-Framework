﻿namespace BookShop
{
    using BookShop.Models.Enums;
    using Data;
    using Initializer;
    using Microsoft.EntityFrameworkCore;
    using System.Collections.Immutable;
    using System.Globalization;
    using System.Text;
    using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();

            //NOTE: Uncomment this line to create/recreate DB locally
            //DbInitializer.ResetDatabase(db);

            Console.WriteLine(GetTotalProfitByCategory(db));
        }
        public static string GetTotalProfitByCategory(BookShopContext context)
        {
            var categories = context.Categories
                .Select(c => new { 
                    c.Name,
                    BooksPrice = c.CategoryBooks.ToList().Sum(cb => cb.Book.Price * cb.Book.Copies)
                })
                .ToList()
                .OrderByDescending(c => c.BooksPrice)
                .ThenBy(c => c.Name);

            return string.Join(Environment.NewLine, categories.Select(c => $"{c.Name} ${c.BooksPrice:f2}"));
        }
    }
}


