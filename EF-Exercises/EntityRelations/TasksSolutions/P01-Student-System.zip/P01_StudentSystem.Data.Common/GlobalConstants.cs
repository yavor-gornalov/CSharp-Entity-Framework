﻿namespace P01_StudentSystem.Data.Common;

public static class GlobalConstants
{
    public const int PhoneNumberLength = 10;
    public const int StudentNameMaxLength = 100;
    public const int CourseNameMaxLength = 80;
    public const int ResourceNameMaxLength = 50;

}
