﻿namespace P01_StudentSystem.Data.Common;

public static class Config
{
    public const string ConnectionString =
        @"Server=DESKTOP-K6C0UOL\SQLEXPRESS;Database=StudentSystem;Integrated Security=True;";
}
