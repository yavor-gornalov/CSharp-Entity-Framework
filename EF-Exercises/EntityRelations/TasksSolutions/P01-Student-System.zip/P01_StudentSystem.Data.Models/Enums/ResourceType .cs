﻿namespace P01_StudentSystem.Data.Models.Enums;

public enum ResourceType
{
    Other,
    Video,
    Presentation,
    Document,
}
