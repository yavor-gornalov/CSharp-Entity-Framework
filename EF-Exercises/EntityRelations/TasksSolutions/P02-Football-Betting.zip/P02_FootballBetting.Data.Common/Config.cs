﻿namespace P02_FootballBetting.Data.Common;

public static class Config
{
    public const string ConnectionString =
        @"Server=DESKTOP-K6C0UOL\SQLEXPRESS;Database=FootballBetting;Integrated Security=True;";
}
