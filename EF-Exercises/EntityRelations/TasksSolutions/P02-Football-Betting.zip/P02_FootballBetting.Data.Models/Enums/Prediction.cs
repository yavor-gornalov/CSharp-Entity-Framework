﻿namespace P02_FootballBetting.Data.Models.Enums;

public enum Prediction
{
    Draw = 0,
    Home = 1,
    Away = 2,
}
