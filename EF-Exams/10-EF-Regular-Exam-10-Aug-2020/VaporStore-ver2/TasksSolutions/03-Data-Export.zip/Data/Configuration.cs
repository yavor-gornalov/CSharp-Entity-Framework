﻿namespace VaporStore.Data
{
    public static class Configuration
    {
        public static string ConnectionString =
            @"Server=.\SQLEXPRESS;Database=VaporStoreExamDb;Integrated Security=True;Encrypt=False";
    }
}