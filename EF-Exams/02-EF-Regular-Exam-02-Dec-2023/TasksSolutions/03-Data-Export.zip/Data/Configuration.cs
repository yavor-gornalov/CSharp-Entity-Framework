﻿namespace Medicines.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=.\SQLEXPRESS;Database=MedicinesDB;Integrated Security=True;";
    }
}
