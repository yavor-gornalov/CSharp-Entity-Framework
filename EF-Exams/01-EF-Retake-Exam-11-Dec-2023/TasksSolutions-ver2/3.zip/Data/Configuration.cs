﻿namespace Cadastre.Data
{
	public class Configuration
	{
		public static string ConnectionString = @"Server=.\SQLEXPRESS;Database=CadastreDb;Integrated Security=True;";
	}
}
