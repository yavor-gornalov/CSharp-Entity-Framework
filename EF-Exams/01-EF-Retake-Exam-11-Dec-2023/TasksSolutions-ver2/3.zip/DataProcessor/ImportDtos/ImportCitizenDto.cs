﻿using Cadastre.Data.Enumerations;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;
using static Cadastre.Common.GlobalConstants;

namespace Cadastre.DataProcessor.ImportDtos;

public class ImportCitizenDto
{
	[Required]
	[JsonPropertyName("FirstName")]
	[StringLength(CitizenFirstNameMaxLength, MinimumLength = CitizenFirstNameMinLength)]
	public string FirstName { get; set; } = null!;

	[Required]
	[JsonPropertyName("LastName")]
	[StringLength(CitizenLastNameMaxLength, MinimumLength = CitizenLastNameMinLength)]
	public string LastName { get; set; } = null!;

	[Required]
	[JsonPropertyName("BirthDate")]
	public string BirthDate { get; set; } = null!;

	[Required]
	[JsonPropertyName("MaritalStatus")]
	[EnumDataType(typeof(MaritalStatus))]
	public string MaritalStatus { get; set; } = null!;

	[JsonPropertyName("Properties")]
	public ICollection<int> PropertiesIds { get; set; } = new HashSet<int>();
}

//•	Id – integer, Primary Key
//•	FirstName – text with length[2, 30] (required)
//•	LastName – text with length[2, 30] (required)
//•	BirthDate – DateTime(required)
//•	MaritalStatus - MaritalStatus enum (Unmarried = 0, Married, Divorced, Widowed) (required)
//•	PropertiesCitizens - collection of type PropertyCitizen