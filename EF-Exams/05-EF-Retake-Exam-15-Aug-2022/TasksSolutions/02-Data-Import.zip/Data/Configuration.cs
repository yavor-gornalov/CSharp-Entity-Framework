﻿namespace Trucks.Data
{
	public static class Configuration
	{
		public static string ConnectionString = @"Server=.\SQLEXPRESS;Database=TrucksDB;Integrated Security=True;";
	}
}